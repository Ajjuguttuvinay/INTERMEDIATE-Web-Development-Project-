### Live Demo
```
https://ashiqurrahmananik.github.io/Code-Editor-CodePenbd/
````
### ScreenShot
![Capture](https://user-images.githubusercontent.com/38730778/219613071-54726cfc-16ad-41de-9c81-831317203a6a.JPG)